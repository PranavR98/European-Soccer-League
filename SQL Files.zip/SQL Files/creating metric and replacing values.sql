create table lnl_metric
(   `lnh_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `lnh_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`lnh_metric_id`)
  );
  
alter table lnl_metric
rename column lnh_metric_name to lnl_metric_name;


select * from lnl_metric;


create table sml_metric
(   `sml_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `sml_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`sml_metric_id`)
  );
  
  insert into sml_metric(sml_metric_name)
  values("long");
  
  select * from sml_metric;
  
  
  create table fo_metric
  (   `fo_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `fo_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`fo_metric_id`)
  );
  
    insert into fo_metric(fo_metric_name)
  values("Organized");
  
  select * from fo_metric;
  
    create table snr_metric
  (   `snr_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `snr_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`snr_metric_id`)
  );
  
      insert into snr_metric(snr_metric_name)
  values("risky");
  
    select * from snr_metric;
    
    
    
    create table mhd_metric
  (   `mhd_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `mhd_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`mhd_metric_id`)
  );

      insert into mhd_metric(mhd_metric_name)
  values("deep");
  
      create table cpd_metric
  (   `cpd_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `cpd_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`cpd_metric_id`)
  );
  
        insert into cpd_metric(cpd_metric_name)
  values("double");
  
  select * from cpd_metric;
  
  
        create table co_metric
  (   `co_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `co_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`co_metric_id`)
  );
  
  insert into co_metric (co_metric_name)
  values("offside trap");
  
  select * from lmh_metric;
  
  
         create table sbf_metric
  (   `sbf_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `sbf_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`sbf_metric_id`)
  );
  
   insert into sbf_metric (sbf_metric_name)
  values("fast");
  
           create table nnw_metric
  (   `nnw_metric_id` smallint NOT NULL AUTO_INCREMENT,
  `nnw_metric_name` varchar(16) NOT NULL,
  PRIMARY KEY (`nnw_metric_id`)
  );
  
     insert into nnw_metric (nnw_metric_name)
  values("wide");