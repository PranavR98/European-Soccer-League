#more table creations to normalize database

#lmh_rating table
create table lmh_metric 
( lmh_metric_id smallint(3) auto_increment primary key not null,
lmh_metric_name varchar(16) not null);

insert into lmh_metric(lmh_metric_name) values("High");

select * from lmh_metric;

