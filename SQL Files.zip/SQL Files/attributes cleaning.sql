select distinct(team_api_id) from team_attributes;


select distinct(team_api_id) from team;


SELECT *
FROM team t
LEFT JOIN team_attributes ta
ON t.team_api_id = ta.team_api_id
WHERE ta.team_api_id IS NULL;

select * from team_attributes;
select count(buildUpPlaySpeedClass) from team_attributes
group by buildUpPlaySpeedClass;


select (buildUpPlaySpeed) from team_attributes;


select count(buildUpPlayDribbling) from team_attributes
group by buildUpPlayDribbling;


set @var1 =  (select floor(avg(buildUpPlayDribbling)) from team_attributes);
select @var1;
update team_attributes
set buildUpPlayDribbling = @var1
where buildUpPlayDribbling is null;

select distinct(chanceCreationCrossingClass) from team_attributes
group by chanceCreationCrossingClass;

select * from team_attributes;  

update team_attributes
set buildUpPlaySpeedclass = 3
where buildUpPlaySpeedclass = "Fast";

update team_attributes
set buildUpPlayDribblingClass = 3
where buildUpPlayDribblingClass = "Lots";

update team_attributes
set buildUpPlayPassingClass = 3
where buildUpPlayPassingClass = "Long";

update team_attributes
set buildUpPlayPositioningClass = 2
where buildUpPlayPositioningClass = "Organised";
  
  update team_attributes
set chanceCreationPassingClass = 3
where chanceCreationPassingClass = "Risky";

  update team_attributes
set chanceCreationCrossingClass = 3
where chanceCreationCrossingClass = "Lots";


  update team_attributes
set chanceCreationShootingClass = 3
where chanceCreationShootingClass = "Lots";

  update team_attributes
set chanceCreationPositioningClass = 2
where chanceCreationPositioningClass = "Organised";

select * from fo_metric;

  update team_attributes
set defencePressureClass = 3
where defencePressureClass = "Deep";

  update team_attributes
set defenceAggressionClass = 1
where defenceAggressionClass = "Contain";

select * from nnw_metric;

  update team_attributes
set defenceTeamWidthClass = 3
where defenceTeamWidthClass = "Wide";

  update team_attributes
set defenceDefenderLineClass = 2
where defenceDefenderLineClass = "Offside Trap";