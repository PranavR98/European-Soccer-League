#cleaning player attribute table


select attacking_work_rate, count(attacking_work_rate) from depa.player_attributes
group by attacking_work_rate;

SET SQL_SAFE_UPDATES = 0;
#####
# working on attacking work rate column
#####
#setting none to medium
update depa.player_attributes
set attacking_work_rate = "medium" where attacking_work_rate = "None";

#setting le to low
update depa.player_attributes
set attacking_work_rate = "low" where attacking_work_rate = "le";

#setting norm to medium
update depa.player_attributes
set attacking_work_rate = "medium" where attacking_work_rate = "norm";

#setting norm to medium
update depa.player_attributes
set attacking_work_rate = "medium" where attacking_work_rate = "stoc";

#setting norm to medium
update depa.player_attributes
set attacking_work_rate = "medium" where attacking_work_rate = "y";


####
# working on defensive work rate
# rating is there: 0-3 low, 4-6 med, 7-9 high
####

select * from depa.player_attributes;
select defensive_work_rate, count(defensive_work_rate) from depa.player_attributes
group by defensive_work_rate;


update depa.player_attributes
set defensive_work_rate = "low" where defensive_work_rate = "_0" or defensive_work_rate = "1" or defensive_work_rate = "2" or defensive_work_rate = "3";


update depa.player_attributes
set defensive_work_rate = "medium" where defensive_work_rate = "4" or defensive_work_rate = "5" or defensive_work_rate = "6" or defensive_work_rate = "ormal";


update depa.player_attributes
set defensive_work_rate = "high" where defensive_work_rate = "7" or defensive_work_rate = "8" or defensive_work_rate = "9" or defensive_work_rate = "tocky";

update depa.player_attributes
set defensive_work_rate = "medium" where defensive_work_rate = "ean" ;

update depa.player_attributes
set defensive_work_rate = "medium" where defensive_work_rate = "es" ;

####
#Fixing Null with average values or mode if character
###

update depa.player_attributes
set attacking_work_rate = "medium" where attacking_work_rate is null ;


#inserting avergae into missing columns
select * from depa.player_attributes
where acceleration is null;

set @var1 = (select floor(avg(gk_reflexes)) from depa.player_attributes);
select @var1;
update depa.player_attributes
set gk_reflexes = @var1 where gk_reflexes is null ;

 



select * from depa.player_attributes;

#replacing low med high with keys
update depa.player_attributes
set defensive_work_rate = "1" where defensive_work_rate = "low" ; 

